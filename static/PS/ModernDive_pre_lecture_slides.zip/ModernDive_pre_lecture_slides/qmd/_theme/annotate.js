// Place the chips over the code they name, and draw a curly brace between.
//
// The slide source stays plain markdown: a paragraph of chips, a fenced R
// block, and (optionally) another paragraph of chips underneath.
//
//   [Data frame]{.chip .green at="data = weather"}
//
//   ```r
//   ggplot(data = weather, aes(x = temp)) +
//   ```
//
// Each label names the span of code it points at with `at=`, a substring of
// the call. Nothing in the source refers to a coordinate, and nothing has to be
// re-measured by hand when the code changes.
//
// Which way a brace points is not stated either: a row written above the code
// block labels it from above, a row written below labels it from below.

(function () {
  "use strict";

  var SVG = "http://www.w3.org/2000/svg";
  var CHIP_GAP = 6;   // the least space left between two chips, in px
  var CODE_MAX_WIDTH = 900;  // the widest a band may be, in slide points
  var CODE_MAX_BOTTOM = 430; // captions below it need the rest of the page

  // ---- find the characters `at` names, inside the highlighted code ---------
  //
  // Pandoc splits a line of R into a span per token, so the text is spread over
  // many nodes. Walk them once, build the flat string plus an index, then map a
  // substring match back onto a Range.

  function textNodes(root) {
    var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    var nodes = [];
    var n;
    while ((n = walker.nextNode())) nodes.push(n);
    return nodes;
  }

  function rangeFor(code, needle) {
    var nodes = textNodes(code);
    var flat = "";
    var map = [];
    nodes.forEach(function (node) {
      for (var i = 0; i < node.nodeValue.length; i++) map.push([node, i]);
      flat += node.nodeValue;
    });

    var at = flat.indexOf(needle);
    // A name is matched as a whole word: at="flights" must not land inside
    // on_time_flights, which is the result, not the data frame.
    if (/^[A-Za-z_.][\w.]*$/.test(needle)) {
      var word = new RegExp("(^|[^\\w.])" + needle.replace(/\./g, "\\.") +
                            "(?![\\w.])");
      var m = word.exec(flat);
      at = m ? m.index + m[1].length : -1;
    }
    if (at < 0) {
      // Fall back to a whitespace-insensitive match, so a chip can name a call
      // the way it reads rather than the way it wrapped.
      var loose = needle.replace(/\s+/g, " ").trim();
      at = flat.replace(/\s+/g, " ").indexOf(loose);
      if (at < 0) return null;
    }
    var end = at + needle.length - 1;
    if (!map[at] || !map[end]) return null;

    var r = document.createRange();
    r.setStart(map[at][0], map[at][1]);
    r.setEnd(map[end][0], map[end][1] + 1);
    return r;
  }

  // ---- a curly brace spanning x0..x1 --------------------------------------
  //
  // Two symmetric halves meeting at a center tip, the shape the original decks
  // draw. `down` points from the chip row down onto the code.

  function bracePath(x0, x1, h, down) {
    var mid = (x0 + x1) / 2;
    var y0 = down ? 0 : h;      // the flat side, level with the chip
    var y1 = down ? h : 0;      // the tips, touching the code
    var k = Math.min(8, (x1 - x0) / 4);
    var s = down ? 1 : -1;
    return [
      "M", x0, y1,
      "q", 0, s * -k, k, s * -k,
      "H", mid - k,
      "q", k, 0, k, s * -k,
      "q", 0, s * k, k, s * k,
      "H", x1 - k,
      "q", k, 0, k, s * k
    ].join(" ");
  }

  // ---- decide which paragraphs are chip rows -------------------------------

  function isChipRow(el) {
    if (!el || el.tagName !== "P") return false;
    var kids = Array.prototype.filter.call(el.childNodes, function (n) {
      return n.nodeType !== 3 || n.nodeValue.trim() !== "";
    });
    return kids.length > 0 && kids.every(function (n) {
      return n.nodeType === 1 &&
             (n.classList.contains("chip") || n.classList.contains("brace"));
    });
  }

  function codeNear(row, forward) {
    var el = forward ? row.nextElementSibling : row.previousElementSibling;
    while (el) {
      var code = el.querySelector && el.querySelector("pre code");
      if (code) return code;
      if (el.tagName === "P" && !isChipRow(el)) return null;
      el = forward ? el.nextElementSibling : el.previousElementSibling;
    }
    return null;
  }

  // ---- lay one row out ------------------------------------------------------

  // The top of the band's first line of text and the bottom of its last. A row
  // above the code can only point at the first line, and a row below only at
  // the last: a brace drawn across the gap lands on whatever line is nearest.
  function lineEdges(code) {
    // Text only: each line also carries an empty anchor for its line number,
    // and those report boxes that sit nowhere near the text.
    var rects = [];
    textNodes(code).forEach(function (node) {
      if (!node.nodeValue.trim()) return;
      var r = document.createRange();
      r.selectNodeContents(node);
      Array.prototype.forEach.call(r.getClientRects(), function (b) {
        if (b.width > 0 && b.height > 0) rects.push(b);
      });
    });
    if (!rects.length) return null;
    return {
      top: Math.min.apply(null, rects.map(function (b) { return b.top; })),
      bottom: Math.max.apply(null, rects.map(function (b) { return b.bottom; }))
    };
  }

  function isSideRow(el) {
    return isChipRow(el) && Array.prototype.every.call(
      el.querySelectorAll(".chip, .brace"),
      function (c) { return c.classList.contains("side"); });
  }

  function place(row, code, down) {
    var chips = Array.prototype.slice.call(row.querySelectorAll(".chip, .brace"));
    if (!chips.length) return;

    var rowBox = row.getBoundingClientRect();

    // ch02 draws a thin black brace up to a filled chip; ch03 draws a thick
    // yellow one up to a bare colored caption. The row says which it is.
    var gap = document.createElement("div");
    gap.className = "bracegap" +
      (chips[0].classList.contains("brace") ? " yellow" : "");
    if (down) row.after(gap); else row.before(gap);

    var svg = document.createElementNS(SVG, "svg");
    gap.appendChild(svg);
    var gapBox = gap.getBoundingClientRect();
    // Measured after the gap goes in, which moves the code down; the spans
    // below are measured then too, so the two agree.
    var edges = lineEdges(code);

    // Measure everything before moving anything: while the row is still in
    // normal flow each chip reports its natural width.
    var items = [];
    chips.forEach(function (chip) {
      // Pandoc renames a non-standard attribute, so `at=` in the source
      // arrives here as `data-at`.
      var needle = chip.getAttribute("data-at") || chip.getAttribute("at");
      if (!needle) return;
      var span = rangeFor(code, needle);
      if (!span) {
        console.warn("[annotate] no code matches at=" + JSON.stringify(needle));
        return;
      }
      var box = span.getBoundingClientRect();
      // A label above the code naming something on line 2 gets a brace on line
      // 1, under text it does not mean. Flag it so check_layout.R fails the
      // slide; the fix is a `.side` label, which points at its own line.
      if (edges && Math.abs(down ? box.top - edges.top
                                 : box.bottom - edges.bottom) > 3) {
        chip.setAttribute("data-pl-wrong-line", "1");
        console.warn("[annotate] at=" + JSON.stringify(needle) +
          " is not on the line next to its label row; use .side");
      }
      items.push({
        chip: chip,
        width: chip.offsetWidth,
        box: box,
        wanted: box.left + box.width / 2 - rowBox.left
      });
    });
    if (!items.length) return;

    row.classList.add("placed", down ? "down" : "up");

    // A label is usually wider than the code it names, so neighbouring chips
    // compete for the same space. Give each one its span's center where that
    // fits, and slide the rest along rather than letting them overlap.
    items.sort(function (a, b) { return a.wanted - b.wanted; });

    var edge = 0;
    items.forEach(function (it) {
      it.left = Math.max(edge, Math.round(it.wanted - it.width / 2));
      edge = it.left + it.width + CHIP_GAP;
    });

    // Only if that ran past the right edge is anything pulled back. Running
    // this pass unconditionally drags every label leftward off its own span.
    var last = items[items.length - 1];
    if (last.left + last.width > rowBox.width) {
      var limit = rowBox.width;
      for (var i = items.length - 1; i >= 0; i--) {
        if (items[i].left + items[i].width > limit) {
          items[i].left = limit - items[i].width;
        }
        limit = items[i].left - CHIP_GAP;
      }
    }

    items.forEach(function (it) {
      it.chip.style.left = Math.max(0, it.left) + "px";
      // Keep the width it was spaced at. Taken out of the flow, a label that
      // wrapped while measured unwraps, grows, and runs into its neighbour.
      it.chip.style.width = it.width + "px";

      // The brace still spans the real code, whatever the label had to do.
      // Its tips curve a few points past each end, so both are held inside the
      // page: a brace on the last argument of a wide call would otherwise be
      // drawn off the right edge.
      var x0 = Math.max(2, it.box.left - gapBox.left);
      var x1 = Math.min(gapBox.width - 2, it.box.right - gapBox.left);
      var p = document.createElementNS(SVG, "path");
      p.setAttribute("d", bracePath(x0, x1, gapBox.height, down));
      svg.appendChild(p);
    });
  }

  // ---- when to run -----------------------------------------------------
  //
  // reveal.js keeps only the slides near the current one laid out; the rest are
  // display:none and every measurement on them comes back zero. So a slide is
  // annotated when it is first shown, not once for the whole deck.

  function annotate(section) {
    if (!section || section.dataset.plAnnotated) return;
    if (!section.offsetWidth && !section.offsetHeight) return;  // still hidden
    section.dataset.plAnnotated = "1";

    drawDiagrams(section);
    placeBanner(section);
    placeDiagram(section);
    placeCode(section);

    section.querySelectorAll("p").forEach(function (row) {
      if (!isChipRow(row) || row.classList.contains("placed")) return;
      if (isSideRow(row)) return;   // placed last, once the band has settled
      // Where the row sits in the source is what says which side of the code
      // it labels: before the code means above it, after means below.
      var code = codeNear(row, true);
      if (code) { place(row, code, true); return; }
      code = codeNear(row, false);
      if (code) place(row, code, false);
    });

    section.querySelectorAll("p").forEach(function (row) {
      if (!isSideRow(row) || row.classList.contains("placed")) return;
      var code = codeNear(row, false) || codeNear(row, true);
      if (code) placeSide(section, row, code);
    });

    // Last, because it has to clear the band at its final size and the row of
    // labels sitting over it, neither of which exists until the steps above run.
    placeGutter(section);
  }

  // ---- a label beside a line in the middle of a call -------------------------
  //
  // The 2018 decks pointed at a middle line with a diagonal arrow drawn over the
  // line above it. Here the label sits to the right of the line it names, an
  // arrow runs from it to the end of that line, and the exact code it means is
  // underlined in the brace yellow. Nothing is drawn across other code.
  //
  //   [what to group by]{.brace .side at="origin"}

  var SIDE_GAP = 40;   // from the end of the line's text to the label

  function placeSide(section, row, code) {
    row.classList.add("placed", "side-row");
    var scale = (window.Reveal && Reveal.getScale) ? Reveal.getScale() : 1;
    var sec = section.getBoundingClientRect();
    var sx = function (x) { return (x - sec.left) / scale; };
    var sy = function (y) { return (y - sec.top) / scale; };

    var svg = document.createElementNS(SVG, "svg");
    svg.setAttribute("class", "side-marks");
    svg.setAttribute("aria-hidden", "true");
    section.appendChild(svg);

    // Every line's ink, so a label can start past whichever lines it sits
    // beside: one that wraps to two lines must clear the line below as well.
    var inkBoxes = [];
    textNodes(code).forEach(function (node) {
      if (!node.nodeValue.trim()) return;
      var r = document.createRange();
      r.selectNodeContents(node);
      Array.prototype.forEach.call(r.getClientRects(), function (b) {
        if (b.width > 0) inkBoxes.push(b);
      });
    });
    function rightOfInk(top, bottom) {   // in client coordinates
      var right = 0;
      inkBoxes.forEach(function (b) {
        if (b.bottom > top + 1 && b.top < bottom - 1) right = Math.max(right, b.right);
      });
      return right;
    }

    row.querySelectorAll(".side").forEach(function (chip) {
      var needle = chip.getAttribute("data-at") || chip.getAttribute("at");
      var span = needle && rangeFor(code, needle);
      if (!span) {
        console.warn("[annotate] no code matches at=" + JSON.stringify(needle));
        return;
      }
      var box = span.getBoundingClientRect();

      // Where this line's text ends: extend the match to the next newline.
      var tail = document.createRange();
      tail.setStart(span.endContainer, span.endOffset);
      tail.setEnd(code, code.childNodes.length);
      var lineEnd = box.right;
      Array.prototype.forEach.call(tail.getClientRects(), function (b) {
        if (b.width > 0 && Math.abs(b.top - box.top) < 2) {
          lineEnd = Math.max(lineEnd, b.right);
        }
      });

      var mid = sy((box.top + box.bottom) / 2);
      var x0 = sx(lineEnd) + 8;
      // Height first (it depends on the width the label wraps to), then the
      // lines its height spans, then how far right it must start to clear them.
      // Measured at the left edge, then held at that width: an absolutely
      // placed label near the right edge would otherwise shrink to the space
      // left and wrap a word to a line.
      chip.style.left = "0px";
      chip.style.width = Math.ceil(chip.getBoundingClientRect().width / scale) + 1 + "px";
      var h = chip.offsetHeight;
      var cmid = (box.top + box.bottom) / 2;
      var half = h * scale / 2;
      var labelLeft = sx(Math.max(rightOfInk(cmid - half, cmid + half), lineEnd)) +
                      SIDE_GAP;
      chip.style.left = labelLeft + "px";
      chip.style.top = Math.round(mid - h / 2) + "px";

      var arrow = document.createElementNS(SVG, "path");
      var x1 = labelLeft - 6;
      arrow.setAttribute("d", "M" + x1 + " " + mid + " H" + x0 +
        " M" + (x0 + 7) + " " + (mid - 5) + " L" + x0 + " " + mid +
        " L" + (x0 + 7) + " " + (mid + 5));
      arrow.setAttribute("class", "side-arrow");
      svg.appendChild(arrow);

      var under = document.createElementNS(SVG, "path");
      var y = sy(box.bottom) + 1;
      under.setAttribute("d", "M" + sx(box.left) + " " + y + " H" + sx(box.right));
      under.setAttribute("class", "side-under");
      svg.appendChild(under);
    });
  }

  // ---- put the code band where the deck says ------------------------------
  //
  // A worked call states the y its band sits at, because that does not follow
  // from the slide's own content. Everything above the band (a row of labels
  // and its brace gap) is in normal flow, so the offset goes on the first thing
  // in that flow and the band follows it down.

  function placeCode(section) {
    var band = section.querySelector("div.sourceCode");
    if (!band || section.dataset.plCoded) return;
    section.dataset.plCoded = "1";

    // Fitting the call and placing it are separate jobs. Every call has to fit;
    // only some state where they sit. Gating the fit behind code-y left the
    // widest calls in the decks running off the right edge of the page.
    var stated_y = parseInt(section.getAttribute("data-code-y"), 10);
    var target = isNaN(stated_y) ? 0 : stated_y;

    // The R engine stepped the call down a ladder of sizes until it fit the
    // slide, and the decks were written expecting that. Same ladder here: an
    // explicit code-size wins, otherwise shrink until the band fits.
    var code = band.querySelector("code");
    var stated = parseInt(section.getAttribute("data-code-size"), 10);
    if (code) {
      if (!isNaN(stated)) {
        code.style.fontSize = (stated / 24) + "em";
      } else {
        var ladder = [26, 24, 22, 20, 18, 16, 14];
        // A .code-left band starts at x=215 instead of hanging off the right
        // margin, so it has that much less room.
        var maxWide = section.classList.contains("code-left")
          ? 960 - 30 - 215 : CODE_MAX_WIDTH;
        for (var k = 0; k < ladder.length; k++) {
          code.style.fontSize = (ladder[k] / 24) + "em";
          var fitsWide = Math.max(band.scrollWidth, band.offsetWidth) <= maxWide;
          // A tall call has to leave the foot of the slide free for the
          // captions that point up at it, so height counts as well as width.
          var fitsTall = target + band.offsetHeight <= CODE_MAX_BOTTOM;
          if (fitsWide && fitsTall) break;
        }
      }
    }

    if (isNaN(stated_y)) return;   // fitted, but this slide places it by flow

    var sec = section.getBoundingClientRect();
    var scale = (window.Reveal && Reveal.getScale) ? Reveal.getScale() : 1;
    var now = (band.getBoundingClientRect().top - sec.top) / scale;

    var first = null;
    for (var i = 0; i < section.children.length; i++) {
      var el = section.children[i];
      if (getComputedStyle(el).position !== "absolute") { first = el; break; }
    }
    if (!first) return;
    var cur = parseFloat(getComputedStyle(first).marginTop) || 0;
    first.style.marginTop = Math.round(cur + (target - now)) + "px";
  }

  // ---- keep the gutter word clear of the code band -------------------------
  //
  // ch03 sets the word "Example" in the left gutter, beside a short call. A
  // long call fills that gutter: the band is sized to its own content and hangs
  // off the right margin, so the wider it is the further left it reaches. When
  // the two would overlap, the word moves above the band instead of beside it.

  var GUTTER_GAP = 10;
  var GUTTER_FLOOR = 120;   // below the verb, which owns the top of the slide

  function placeGutter(section) {
    var word = section.querySelector(".example-label");
    var band = section.querySelector("div.sourceCode");
    if (!word || !band || word.dataset.plPlaced) return;
    word.dataset.plPlaced = "1";

    var w = word.getBoundingClientRect(), b = band.getBoundingClientRect();
    if (w.right <= b.left) return;                 // already clear beside it
    if (w.top >= b.bottom || w.bottom <= b.top) return;  // above or below it

    // No room beside the call, so try above it. "Above" means above whatever
    // sits over the band too, or the word lands on a row of labels.
    var top = b.top;
    var row = section.querySelector(".placed.down");
    if (row) {
      top = Math.min(top, row.getBoundingClientRect().top);
      // A two-line label rises above its row, which is only one line tall.
      Array.prototype.forEach.call(row.children, function (c) {
        top = Math.min(top, c.getBoundingClientRect().top);
      });
    }

    var sec = section.getBoundingClientRect();
    var scale = (window.Reveal && Reveal.getScale) ? Reveal.getScale() : 1;
    var y = (top - sec.top) / scale - w.height / scale - GUTTER_GAP;

    if (y < GUTTER_FLOOR) {
      // A call this wide leaves the gutter nowhere to go. The word is a label
      // on a slide that is plainly an example, so it stands down.
      word.style.display = "none";
      return;
    }
    word.style.top = Math.round(y) + "px";
  }

  // ---- keep the banner clear of the note ----------------------------------
  //
  // The note sits at the top right and can run to four lines. The banner is
  // centered across the slide, so a long note would be drawn over. The R engine
  // pushes the banner down to clear the note's last line; this does the same,
  // by measurement rather than by counting lines.

  var BANNER_GAP = 8;

  function placeBanner(section) {
    var banner = section.querySelector(".banner");
    if (!banner || banner.dataset.plPlaced) return;
    var row = banner.parentNode;
    var note = section.querySelector(".note") ||
               section.querySelector("section.concept > p:first-of-type");
    if (!note) return;
    banner.dataset.plPlaced = "1";

    var nb = note.getBoundingClientRect();
    var bb = banner.getBoundingClientRect();
    if (nb.bottom + BANNER_GAP <= bb.top) return;   // already clear

    var sec = section.getBoundingClientRect();
    var scale = (window.Reveal && Reveal.getScale) ? Reveal.getScale() : 1;
    var top = (nb.bottom - sec.top) / scale + BANNER_GAP;
    row.style.top = Math.round(top) + "px";
  }

  // A diagram sits at a fixed height under the banner. When the banner reaches
  // down onto it (a long note pushes the banner down), the diagram moves down.
  function placeDiagram(section) {
    var banner = section.querySelector(".banner");
    var diagram = section.querySelector(".diagram");
    if (!banner || !diagram) return;
    var sec = section.getBoundingClientRect();
    var scale = (window.Reveal && Reveal.getScale) ? Reveal.getScale() : 1;
    var bb = banner.getBoundingClientRect();
    var db = diagram.getBoundingClientRect();
    if (db.top < bb.bottom + BANNER_GAP) {
      diagram.style.top = Math.round((bb.bottom - sec.top) / scale +
                                     BANNER_GAP) + "px";
    }
  }

  // ---- the data frame diagrams --------------------------------------------
  //
  // A concept slide can show a data frame before and after a verb, as two grids
  // of cells with an arrow between. The source writes the shape, not the cells:
  //
  //   []{.diagram kind="columns" cols="5" rows="4" from_cols="0,1" to_cols="2"}

  function nums(el, name) {
    var v = el.getAttribute("data-" + name) || el.getAttribute(name);
    if (!v) return [];
    return v.split(",").map(function (x) { return parseInt(x, 10); })
            .filter(function (x) { return !isNaN(x); });
  }

  function one(el, name, fallback) {
    var v = nums(el, name);
    return v.length ? v[0] : fallback;
  }

  function grid(cols, rows, lit, kind) {
    var g = document.createElement("div");
    g.className = "grid";
    g.style.gridTemplateColumns = "repeat(" + cols + ", auto)";
    for (var r = 0; r < rows; r++) {
      for (var c = 0; c < cols; c++) {
        var cell = document.createElement("div");
        var on = kind === "columns" ? lit.indexOf(c) >= 0 : lit.indexOf(r) >= 0;
        cell.className = "cell" + (on ? " on" : "") + (r === 0 ? " head" : "");
        g.appendChild(cell);
      }
    }
    return g;
  }

  // ---- say in words what a diagram draws in color --------------------------
  //
  // A diagram is two grids of blank cells and an arrow between them: the table
  // before a verb runs, and the table after. It contains no text at all, and
  // which cells are picked out is carried entirely by fill color, so on its own
  // it reaches a screen reader as nothing whatsoever. The same attributes that
  // drive the drawing describe it, so the label costs nothing to keep true.
  //
  // What the diagram *means* is already on the slide, in the note and the
  // banner beside it. This says only what is drawn, so the two do not compete.

  var ORDINALS = ["1st", "2nd", "3rd", "4th", "5th", "6th",
                  "7th", "8th", "9th", "10th"];

  function ordinal(i) { return ORDINALS[i] || (i + 1) + "th"; }

  function series(parts) {
    if (parts.length === 1) return parts[0];
    if (parts.length === 2) return parts[0] + " and " + parts[1];
    return parts.slice(0, -1).join(", ") + ", and " + parts[parts.length - 1];
  }

  function describe(kind, cols, rows, from, toCols, toRows) {
    var noun = kind === "columns" ? "column" : "row";
    var total = kind === "columns" ? cols : rows;
    var picked = from.length >= total
      ? "every " + noun + " highlighted"
      : series(from.map(ordinal)) + " " + noun +
        (from.length > 1 ? "s" : "") + " highlighted";
    return "Diagram: a table of " + cols + " columns and " + rows +
           " rows, with " + picked + ", becomes a table of " + toCols +
           " columns and " + toRows + " rows.";
  }

  // kind="sort": arrange() reorders rows rather than picking some. The column
  // being sorted carries its values as text, so the order is read, not guessed
  // from shading:  []{.diagram kind="sort" cols="4" col="1" values="3,1,4,2"}
  function drawSort(el) {
    var cols = one(el, "cols", 4);
    var at = one(el, "col", 1);
    var values = nums(el, "values");
    var sorted = values.slice().sort(function (a, b) { return a - b; });
    if (el.getAttribute("data-desc") || el.getAttribute("desc")) sorted.reverse();

    function table(vals) {
      var g = document.createElement("div");
      g.className = "grid sort";
      g.style.gridTemplateColumns = "repeat(" + cols + ", auto)";
      for (var r = 0; r <= vals.length; r++) {
        for (var c = 0; c < cols; c++) {
          var cell = document.createElement("div");
          cell.className = "cell" + (r === 0 ? " head" : "") +
            (c === at ? " on" : "");
          if (r > 0 && c === at) cell.textContent = vals[r - 1];
          g.appendChild(cell);
        }
      }
      return g;
    }
    var arrow = document.createElement("div");
    arrow.className = "arrow";
    arrow.textContent = "→";
    el.appendChild(table(values));
    el.appendChild(arrow);
    el.appendChild(table(sorted));
    el.setAttribute("role", "img");
    el.setAttribute("aria-label", "Diagram: a table of " + cols + " columns and " +
      values.length + " rows, whose " + ordinal(at) + " column reads " +
      series(values.map(String)) + ", becomes the same table with its rows " +
      "reordered so that column reads " + series(sorted.map(String)) + ".");
    for (var n = 0; n < el.children.length; n++) {
      el.children[n].setAttribute("aria-hidden", "true");
    }
  }

  function drawDiagrams(section) {
    section.querySelectorAll(".diagram").forEach(function (el) {
      if (el.dataset.plDrawn) return;
      el.dataset.plDrawn = "1";
      var kind = el.getAttribute("data-kind") || el.getAttribute("kind") || "columns";
      if (kind === "sort") { drawSort(el); return; }
      var cols = one(el, "cols", 5);
      var rows = one(el, "rows", 4);
      var from = nums(el, kind === "columns" ? "from_cols" : "from_rows");
      // With nothing named, every cell of the source is carried over.
      if (!from.length) {
        from = [];
        for (var i = 0; i < (kind === "columns" ? cols : rows); i++) from.push(i);
      }
      var toCols = one(el, "to_cols", cols);
      var toRows = one(el, "to_rows", rows);
      var toLit = [];
      for (var j = 0; j < (kind === "columns" ? toCols : toRows); j++) toLit.push(j);

      var arrow = document.createElement("div");
      arrow.className = "arrow";
      arrow.textContent = "\u2192";

      el.appendChild(grid(cols, rows, from, kind));
      el.appendChild(arrow);
      el.appendChild(grid(toCols, toRows, toLit, kind));

      // One image with one name. Without the hidden branch every blank cell is
      // its own node, and a reader hears the label and then several hundred
      // nothings.
      el.setAttribute("role", "img");
      el.setAttribute("aria-label",
        describe(kind, cols, rows, from, toCols, toRows));
      for (var n = 0; n < el.children.length; n++) {
        el.children[n].setAttribute("aria-hidden", "true");
      }
    });
  }

  function annotateAll() {
    document.querySelectorAll(".reveal section").forEach(annotate);
  }

  // Printing lays every slide out at once, so all of them can be annotated in
  // one pass. Reveal signals this by putting `print-pdf` on the root element,
  // and the deck is opened with ?print-pdf to ask for it.
  function printing() {
    return /print-pdf/.test(window.location.search) ||
           document.documentElement.classList.contains("print-pdf") ||
           document.body.classList.contains("print-pdf");
  }

  function boot() {
    if (window.Reveal && typeof window.Reveal.on === "function") {
      Reveal.on("ready", function (e) {
        if (printing()) annotateAll(); else annotate(e.currentSlide);
      });
      Reveal.on("slidechanged", function (e) { annotate(e.currentSlide); });
      Reveal.on("pdf-ready", annotateAll);
      if (Reveal.isReady && Reveal.isReady()) {
        if (printing()) annotateAll(); else annotate(Reveal.getCurrentSlide());
      }
    } else {
      annotateAll();
    }
  }

  if (document.readyState === "complete") {
    setTimeout(boot, 150);
  } else {
    window.addEventListener("load", function () { setTimeout(boot, 150); });
  }
})();
