// Accessibility repairs for markup the decks do not write themselves: Quarto's
// revealjs template and the reveal.js menu plugin. Found by axe-core 4.10.2 on
// 2026-10-12 (check_a11y.R); each fix names the WCAG criterion it restores.
// render.sh wraps this file into _theme/annotate.js.html with annotate.js, so
// it runs in every deck, including one rendered with plain `quarto render`.
(function () {
  // 1.4.4 Resize text. The template's viewport meta sets maximum-scale=1.0 and
  // user-scalable=no, which stops pinch zoom on a phone or tablet.
  var vp = document.querySelector('meta[name="viewport"]');
  if (vp) vp.setAttribute("content", "width=device-width, initial-scale=1.0");

  function repairMenu() {
    // 2.4.4 and 4.1.2. The menu button is a link holding only an icon, so a
    // screen reader announces it as "link" with no name.
    var a = document.querySelector(".slide-menu-button a");
    if (a) {
      a.setAttribute("aria-label", "Open the slide menu");
      var icon = a.querySelector("i");
      if (icon) icon.setAttribute("aria-hidden", "true");
    }
    // 2.1.1 Keyboard. A panel whose list is longer than the window scrolls,
    // but holds nothing focusable, so the keyboard cannot reach its end.
    document.querySelectorAll(".slide-menu-panel").forEach(function (p) {
      p.setAttribute("tabindex", "0");
      p.setAttribute("role", "region");
      p.setAttribute("aria-label", (p.getAttribute("data-panel") || "Menu") + " panel");
    });
    // 2.4.3 Focus order and 2.4.7 Focus visible. A closed menu is parked
    // 300px off the left edge rather than hidden, so Tab walked into its links
    // where nobody could see them. Keep it inert until it is opened.
    var menu = document.querySelector(".slide-menu");
    if (menu) {
      var sync = function () {
        menu.inert = !menu.classList.contains("active");
      };
      sync();
      new MutationObserver(sync).observe(menu, { attributes: true, attributeFilter: ["class"] });
    }
  }

  // 2.4.3 Focus order. reveal.js 5.1.0 marks the slides near the current one
  // hidden, but its inline display:block overrides that, so Tab from slide 5
  // landed in slide 4's code. reveal.js 6.0.2 makes those slides inert, and
  // Quarto 1.10 still bundles 5.1.0 (quarto-cli #14795, fixed for 1.11).
  // Remove this once the decks render with a Quarto that has the fix.
  function printing() {
    return /print-pdf/.test(window.location.search) ||
           document.documentElement.classList.contains("print-pdf");
  }
  function inertOffscreen() {
    // The overview (Esc) shows every slide to be picked with a click, which
    // an inert slide would ignore.
    var overview = window.Reveal && Reveal.isOverview && Reveal.isOverview();
    if (printing()) return;
    document.querySelectorAll(".reveal .slides section").forEach(function (s) {
      s.inert = !overview &&
        !(s.classList.contains("present") || s.querySelector("section.present"));
    });
  }

  function boot() {
    if (window.Reveal && typeof window.Reveal.on === "function") {
      Reveal.on("ready", function () { repairMenu(); inertOffscreen(); });
      Reveal.on("slidechanged", inertOffscreen);
      Reveal.on("overviewshown", inertOffscreen);
      Reveal.on("overviewhidden", inertOffscreen);
      if (Reveal.isReady && Reveal.isReady()) { repairMenu(); inertOffscreen(); }
    } else {
      repairMenu();
    }
  }

  if (document.readyState === "complete") {
    setTimeout(boot, 150);
  } else {
    window.addEventListener("load", function () { setTimeout(boot, 150); });
  }
})();
