# Draw the join and pivot diagrams for the ch03 and ch04 decks.
#
#   Rscript assets/tidyexplain/make_explain.R      (from the qmd folder)
#
# The layout and the palette follow Garrick Aden-Buie's tidyexplain
# (https://github.com/gadenbuie/tidyexplain, CC0 1.0). Its own static PNGs set
# white letters on its pale cells: 1.95:1 on the light green and light orange,
# 2.95:1 on the light purple, 3.22:1 on the green, and 2.93:1 on the orange,
# measured 2026-10-12. Text in an image is held to the same 4.5:1 as any other
# text (WCAG 1.4.3), so these are redrawn with each cell's letters in white or
# near-black, whichever passes, and the script stops if one does not.

suppressPackageStartupMessages(library(ggplot2))

here <- normalizePath(dirname(sub("^--file=", "",
  grep("^--file=", commandArgs(FALSE), value = TRUE)[1])))

pal <- c(
  red = "#DA0017", blue = "#2C69A9", green = "#40A33A", purple = "#843692",
  orange = "#FC6908", gray = "#C6C6C6",
  green_lt = "#8DC889", purple_lt = "#B586BD", orange_lt = "#FDA56B"
)
dark <- "#111111"

luminance <- function(hex) {
  c <- grDevices::col2rgb(hex)[, 1] / 255
  c <- ifelse(c <= 0.03928, c / 12.92, ((c + 0.055) / 1.055)^2.4)
  sum(c(0.2126, 0.7152, 0.0722) * c)
}
contrast <- function(a, b) {
  l <- sort(c(luminance(a), luminance(b)), decreasing = TRUE)
  (l[1] + 0.05) / (l[2] + 0.05)
}
ink <- function(fill) {
  if (contrast("#FFFFFF", fill) >= 4.5) "#FFFFFF" else dark
}
for (f in pal) {
  r <- contrast(ink(f), f)
  if (r < 4.5) stop(sprintf("%s on %s is %.2f:1", ink(f), f, r))
}

# One table: a data frame of cells (col, row, label, fill), drawn with its
# top-left cell at (x0, 0), a title above it, and optional column headers.
row_h <- 0.62
table_cells <- function(cells, x0) {
  transform(cells, x = x0 + col - 1, y = -(row - 1) * row_h,
            ink = vapply(fill, ink, ""))
}

draw <- function(tables, titles, headers, arrows, file) {
  cells <- do.call(rbind, tables)
  top <- max(cells$y) + row_h
  p <- ggplot() +
    geom_tile(data = cells, aes(x, y), fill = cells$fill,
              width = 0.92, height = row_h * 0.88) +
    geom_text(data = cells, aes(x, y, label = label), colour = cells$ink,
              size = 6.2, family = "sans") +
    geom_text(data = titles, aes(x, y, label = label), size = 7,
              family = "mono", colour = dark) +
    geom_text(data = headers, aes(x, y, label = label), size = 5.4,
              family = "sans", colour = dark) +
    geom_segment(data = arrows, aes(x = x, xend = xend, y = y, yend = y),
                 arrow = arrow(length = unit(0.12, "in"), type = "closed"),
                 linewidth = 0.9, colour = dark) +
    coord_fixed(expand = FALSE,
                xlim = c(min(cells$x) - 0.7, max(cells$x) + 0.7),
                ylim = c(min(cells$y) - 0.45, top + 0.75)) +
    theme_void() +
    theme(plot.background = element_rect(fill = "white", colour = NA))
  w <- diff(range(cells$x)) + 1.4
  h <- diff(range(cells$y)) + 1.2 + 0.75
  out <- file.path(here, file)
  ggsave(out, p, width = w * 0.75, height = h * 0.75, dpi = 300, bg = "white")
  # Trim the white margin, so the slide's fixed box shows the cells, not air.
  system2("magick", c(shQuote(out), "-trim", "-bordercolor", "white",
                      "-border", "24", shQuote(out)))
  message("wrote ", file)
}

cell <- function(col, row, label, fill) {
  data.frame(col = col, row = row, label = label, fill = unname(pal[fill]))
}

# inner_join(x, y, by = "id"): only keys 1 and 2 appear in both.
x <- table_cells(rbind(
  cell(1, 1:3, c("1", "2", "3"), c("red", "blue", "green")),
  cell(2, 1:3, c("x1", "x2", "x3"), "gray")), x0 = 0)
y <- table_cells(rbind(
  cell(1, 1:3, c("1", "2", "4"), c("red", "blue", "purple")),
  cell(2, 1:3, c("y1", "y2", "y4"), "gray")), x0 = 3.2)
joined <- table_cells(rbind(
  cell(1, 1:2, c("1", "2"), c("red", "blue")),
  cell(2, 1:2, c("x1", "x2"), "gray"),
  cell(3, 1:2, c("y1", "y2"), "gray")), x0 = 7.6)
draw(list(x, y, joined),
     titles = data.frame(x = c(0.5, 3.7, 8.6), y = 1.25,
                         label = c("x", "y", "result")),
     headers = data.frame(x = c(0, 1, 3.2, 4.2, 7.6, 8.6, 9.6), y = 0.62,
                          # dplyr suffixes a name both tables share
                          label = c("id", "val", "id", "val", "id", "val.x",
                                    "val.y")),
     arrows = data.frame(x = 5.4, xend = 6.8, y = -row_h),
     file = "inner_join.png")

# pivot_longer(): three value columns become a key column and a value column.
wide <- table_cells(rbind(
  cell(1, 1:2, c("1", "2"), c("red", "blue")),
  cell(2, 1:2, c("a", "b"), "green_lt"),
  cell(3, 1:2, c("c", "d"), "purple_lt"),
  cell(4, 1:2, c("e", "f"), "orange_lt")), x0 = 0)
wide_head <- table_cells(
  cell(2:4, 0, c("x", "y", "z"), c("green", "purple", "orange")), x0 = 0)
long_cells <- function(x0) table_cells(rbind(
  cell(1, 1:6, rep(c("1", "2"), 3), rep(c("red", "blue"), 3)),
  cell(2, 1:6, rep(c("x", "y", "z"), each = 2),
       rep(c("green", "purple", "orange"), each = 2)),
  cell(3, 1:6, c("a", "b", "c", "d", "e", "f"),
       rep(c("green_lt", "purple_lt", "orange_lt"), each = 2))), x0 = x0)

draw(list(wide, wide_head, long_cells(6.2)),
     titles = data.frame(x = c(1.5, 7.2), y = 1.25, label = c("wide", "long")),
     headers = data.frame(x = c(0, 6.2, 7.2, 8.2), y = 0.62,
                          label = c("id", "id", "key", "val")),
     arrows = data.frame(x = 4.1, xend = 5.4, y = -row_h),
     file = "pivot_longer.png")

# pivot_wider(): the same two tables, the other way round.
long <- long_cells(0)
wide2 <- table_cells(rbind(
  cell(1, 1:2, c("1", "2"), c("red", "blue")),
  cell(2, 1:2, c("a", "b"), "green_lt"),
  cell(3, 1:2, c("c", "d"), "purple_lt"),
  cell(4, 1:2, c("e", "f"), "orange_lt")), x0 = 4.6)
wide2_head <- table_cells(
  cell(2:4, 0, c("x", "y", "z"), c("green", "purple", "orange")), x0 = 4.6)
draw(list(long, wide2, wide2_head),
     titles = data.frame(x = c(1, 6.1), y = 1.25, label = c("long", "wide")),
     headers = data.frame(x = c(0, 1, 2, 4.6), y = 0.62,
                          label = c("id", "key", "val", "id")),
     arrows = data.frame(x = 2.8, xend = 4.0, y = -row_h),
     file = "pivot_wider.png")
