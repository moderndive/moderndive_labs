# Save a picture of every slide, as a browser shows it, and one contact sheet
# per deck, so a person can look at the whole deck at once.
#
#   Rscript snapshot.R            every deck, into snapshots/
#   Rscript snapshot.R ch03       just the ones whose name starts ch03
#
# Run it after ./render.sh. check_layout.R measures what can be measured; this
# is for what cannot, and it is how a slide that is blank, crowded, or pointing
# a brace at the wrong code gets seen before it ships. Look at every sheet.
# The contact sheets need ImageMagick (`magick`); the slide PNGs do not.

suppressPackageStartupMessages(library(chromote))

`%||%` <- function(a, b) if (is.null(a)) b else a

here <- normalizePath(dirname(sub("^--file=", "",
  grep("^--file=", commandArgs(FALSE), value = TRUE)[1] %||% ".")))
args <- commandArgs(TRUE)

decks <- sort(list.files(here, pattern = "^ch.*\\.html$"))
if (length(args)) {
  decks <- decks[Reduce(`|`, lapply(args, function(a) startsWith(decks, a)))]
}
if (!length(decks)) stop("no rendered decks match; run ./render.sh first")

out_dir <- file.path(here, "snapshots")
dir.create(out_dir, showWarnings = FALSE)

for (deck in decks) {
  stem <- sub("\\.html$", "", deck)
  b <- ChromoteSession$new(width = 960, height = 540)
  b$Page$navigate(paste0("file://", file.path(here, deck)))
  b$Page$loadEventFired(wait_ = TRUE)
  Sys.sleep(2.5)

  n <- b$Runtime$evaluate("Reveal.getTotalSlides()", returnByValue = TRUE)$result$value
  pngs <- character()
  for (i in seq_len(n)) {
    b$Runtime$evaluate(sprintf("Reveal.slide(%d)", i - 1L))
    Sys.sleep(0.75)
    f <- file.path(out_dir, sprintf("%s-%02d.png", stem, i))
    # Not b$screenshot(): it changes the viewport to frame its selector, reveal
    # re-lays the deck out on the resize, and every picture comes back as
    # slide 1. Capturing the page as it stands keeps the slide just shown.
    shot <- b$Page$captureScreenshot(format = "png")
    writeBin(jsonlite::base64_dec(shot$data), f)
    pngs <- c(pngs, f)
  }
  b$close()

  sheet <- file.path(out_dir, paste0(stem, "-sheet.png"))
  if (nzchar(Sys.which("magick"))) {
    system2("magick", c("montage", shQuote(pngs), "-tile", "3x", "-geometry",
                        "480x270+4+4", "-background", "'#888888'", shQuote(sheet)),
            stdout = FALSE, stderr = FALSE)
  }
  cat(sprintf("%-36s %2d slides -> %s\n", stem, n, basename(sheet)))
}
