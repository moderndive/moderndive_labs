# Print each rendered deck to PDF, one page per slide, exactly as a browser
# shows it.
#
#   Rscript to_pdf.R            every deck
#   Rscript to_pdf.R ch05       just the ones whose name starts ch05
#
# Run it after ./render.sh, or use `./render.sh --pdf`, which does both.
# Needs chromote, jsonlite, and pdfunite (poppler).
#
# Each slide is shown, then printed on its own with the page treated as a
# screen, and the pages are joined. This replaced printing the whole deck with
# reveal.js's ?print-pdf mode, which lays every slide out a second, different
# way. In that mode, until 2026-10-11:
#   * a slide whose content ran long spilled onto a blank second page, and the
#     page range then cut the deck's last slides (ch03 lost both select()
#     slides from every PDF since aff382a);
#   * the call-fitting step in annotate.js did not take, so six decks printed a
#     one-line call cut off at the right edge.
# Printing the view that check_layout.R and snapshot.R inspect means the PDF is
# what was checked. The text stays real text, not a picture of it.
#
# A slide is 960 x 540 CSS pixels, which at 96dpi is a 10 x 5.625 inch page.

suppressPackageStartupMessages(library(chromote))

`%||%` <- function(a, b) if (is.null(a)) b else a

here <- normalizePath(dirname(sub("^--file=", "",
  grep("^--file=", commandArgs(FALSE), value = TRUE)[1] %||% ".")))
args <- commandArgs(TRUE)

if (!nzchar(Sys.which("pdfunite"))) stop("pdfunite not found (brew install poppler)")

decks <- sort(list.files(here, pattern = "^ch.*\\.html$"))
if (length(args)) {
  decks <- decks[Reduce(`|`, lapply(args, function(a) startsWith(decks, a)))]
}
if (!length(decks)) stop("no rendered decks match; run ./render.sh first")

for (deck in decks) {
  stem <- sub("\\.html$", "", deck)
  out <- file.path(here, paste0(stem, ".pdf"))
  tmp <- tempfile(stem)
  dir.create(tmp)

  b <- ChromoteSession$new(width = 960, height = 540)
  b$Emulation$setEmulatedMedia(media = "screen")
  b$Page$navigate(paste0("file://", file.path(here, deck)))
  b$Page$loadEventFired(wait_ = TRUE)
  Sys.sleep(2.5)

  # The menu button, the arrows, and the progress bar are for a browser, not a
  # page. The slide number stays.
  b$Runtime$evaluate(paste0(
    "var st = document.createElement('style');",
    "st.textContent = '.reveal .controls, .reveal .progress, .slide-menu-button,",
    " .slide-chalkboard-buttons { display: none !important; }';",
    "document.head.appendChild(st);"))

  n <- b$Runtime$evaluate("Reveal.getTotalSlides()", returnByValue = TRUE)$result$value
  pages <- character()
  for (i in seq_len(n)) {
    b$Runtime$evaluate(sprintf("Reveal.slide(%d)", i - 1L))
    Sys.sleep(0.75)
    res <- b$Page$printToPDF(
      printBackground = TRUE, preferCSSPageSize = FALSE,
      paperWidth = 10, paperHeight = 5.625,
      marginTop = 0, marginBottom = 0, marginLeft = 0, marginRight = 0,
      pageRanges = "1")
    f <- file.path(tmp, sprintf("%03d.pdf", i))
    writeBin(jsonlite::base64_dec(res$data), f)
    pages <- c(pages, f)
  }
  b$close()

  status <- system2("pdfunite", c(shQuote(pages), shQuote(out)))
  if (status != 0) stop("pdfunite failed for ", deck)
  unlink(tmp, recursive = TRUE)
  cat(sprintf("%-40s %2d pages\n", basename(out), n))
}
