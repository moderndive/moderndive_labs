# Run axe-core on every slide of every rendered deck and fail on any WCAG 2.2
# A or AA violation, or any axe best-practice violation.
#
#   Rscript check_a11y.R            every deck
#   Rscript check_a11y.R ch05       just the ones whose name starts ch05
#
# Run it after ./render.sh, beside check_layout.R. axe-core is the engine
# behind most browser accessibility checkers. The script uses axe-core 4.10.2,
# downloaded once from cdnjs into R's user cache directory; set AXE_JS to the
# path of an axe.min.js to use another copy.
#
# Like check_layout.R it visits each slide, because axe skips what is hidden
# and reveal.js hides every slide but the current one.
#
# What axe cannot settle it reports as "needs review". On these decks that is
# almost all color contrast: the annotation layer positions labels, braces, and
# notes absolutely, and axe will not judge text whose box overlaps another box.
# check_layout.R measures the contrast of every text node against its real
# background instead, so the two checks are meant to be run together.
#
# First run, 2026-10-12, before _theme/a11y.js: zoom disabled by the viewport
# meta (all 116 slides), the menu button with no accessible name (116), the
# slide menu panel scrollable but not keyboard reachable (15, ch03), and one
# blank table header (ch02).

suppressPackageStartupMessages({
  library(chromote)
  library(jsonlite)
})

`%||%` <- function(a, b) if (is.null(a)) b else a

here <- normalizePath(dirname(sub("^--file=", "",
  grep("^--file=", commandArgs(FALSE), value = TRUE)[1] %||% ".")))
args <- commandArgs(TRUE)

axe_version <- "4.10.2"
axe_js <- Sys.getenv("AXE_JS")
if (!nzchar(axe_js)) {
  cache <- tools::R_user_dir("moderndive_pre_lecture", "cache")
  dir.create(cache, recursive = TRUE, showWarnings = FALSE)
  axe_js <- file.path(cache, paste0("axe-", axe_version, ".min.js"))
  if (!file.exists(axe_js)) {
    url <- sprintf("https://cdnjs.cloudflare.com/ajax/libs/axe-core/%s/axe.min.js",
                   axe_version)
    download.file(url, axe_js, quiet = TRUE, mode = "wb")
  }
}
axe <- paste(readLines(axe_js, warn = FALSE), collapse = "\n")

decks <- sort(list.files(here, pattern = "^ch.*\\.html$"))
if (length(args)) {
  decks <- decks[Reduce(`|`, lapply(args, function(a) startsWith(decks, a)))]
}
if (!length(decks)) stop("no rendered decks match; run ./render.sh first")

run <- paste0(
  'axe.run(document, {runOnly: {type: "tag", values: ["wcag2a", "wcag2aa", ',
  '"wcag21a", "wcag21aa", "wcag22aa", "best-practice"]}, ',
  'resultTypes: ["violations", "incomplete"]}).then(r => JSON.stringify({',
  'v: r.violations.map(x => ({id: x.id, help: x.help, ',
  'nodes: x.nodes.map(n => n.target.join(" "))})), ',
  'inc: r.incomplete.map(x => ({id: x.id, n: x.nodes.length}))}))')

total <- 0L
review <- list()
for (deck in decks) {
  b <- ChromoteSession$new(width = 960, height = 540)
  b$Page$navigate(paste0("file://", file.path(here, deck)))
  b$Page$loadEventFired(wait_ = TRUE)
  Sys.sleep(2.5)
  b$Runtime$evaluate(axe)

  n <- b$Runtime$evaluate("Reveal.getTotalSlides()", returnByValue = TRUE)$result$value
  msgs <- character()
  for (i in seq_len(n)) {
    b$Runtime$evaluate(sprintf("Reveal.slide(%d)", i - 1L))
    Sys.sleep(0.6)
    r <- fromJSON(b$Runtime$evaluate(run, awaitPromise = TRUE,
                                     returnByValue = TRUE)$result$value,
                  simplifyVector = FALSE)
    for (x in r$v) {
      msgs <- c(msgs, sprintf("slide %d: %s (%s): %s", i, x$id, x$help,
                              paste(unlist(x$nodes), collapse = ", ")))
    }
    for (x in r$inc) review[[x$id]] <- (review[[x$id]] %||% 0L) + x$n
  }
  b$close()

  if (length(msgs)) {
    total <- total + length(msgs)
    cat("\nFAIL ", deck, "\n", paste(msgs, collapse = "\n"), "\n", sep = "")
  } else {
    cat("ok   ", deck, " (", n, " slides)\n", sep = "")
  }
}

if (length(review)) {
  cat("\nneeds review (axe could not decide; elements, summed over slides):\n")
  for (id in names(review)) cat("  ", id, ": ", review[[id]], "\n", sep = "")
  if ("color-contrast" %in% names(review)) {
    cat("  color-contrast is measured by check_layout.R instead; run it too.\n")
  }
}

cat("\nviolations:", total, "\n")
if (total > 0) quit(status = 1)
