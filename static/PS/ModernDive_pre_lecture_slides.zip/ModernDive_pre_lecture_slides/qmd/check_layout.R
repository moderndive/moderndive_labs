# Visit every slide of every deck and fail on what a reader would see as broken.
#
#   Rscript check_layout.R            every deck
#   Rscript check_layout.R ch05       just the ones whose name starts ch05
#
# Run it after ./render.sh. It replaces check_overflow.R, which only asked
# whether anything was drawn off the page. That passed ch03 on 2026-08-28 while
# a heading ran into its note, a diagram covered a heading, and six braces
# pointed at the wrong line of code. Per slide, it checks:
#
#   off-page    anything drawn outside the 960 x 540 page
#   overlap     two pieces of text, code, or picture drawn over each other
#   hidden      a gutter word, note, or label that takes no space or is invisible
#   wrong-line  a brace naming code on a line its row cannot reach (annotate.js)
#   empty       a slide with no visible text or picture
#   alt         an image with no alt, or a decorative one not hidden
#   contrast    text under WCAG AA: 4.5:1, or 3:1 for 24px+ / 18.66px+ bold
#   small-code  a call set under 18px (the decks are designed at 24px)
#
# Each slide has to be visited rather than measured in one pass: reveal.js only
# lays out the slides near the current one, and a hidden slide reports every box
# as zero, which reads as nothing being wrong. Measuring is not looking, though:
# run snapshot.R and look at every contact sheet too.

suppressPackageStartupMessages(library(chromote))

`%||%` <- function(a, b) if (is.null(a)) b else a

here <- normalizePath(dirname(sub("^--file=", "",
  grep("^--file=", commandArgs(FALSE), value = TRUE)[1] %||% ".")))
args <- commandArgs(TRUE)

decks <- sort(list.files(here, pattern = "^ch.*\\.html$"))
if (length(args)) {
  decks <- decks[Reduce(`|`, lapply(args, function(a) startsWith(decks, a)))]
}
if (!length(decks)) stop("no rendered decks match; run ./render.sh first")

probe <- readLines(file.path(here, "check_layout.js"), warn = FALSE)
probe <- paste(probe, collapse = "\n")

total <- 0L
for (deck in decks) {
  b <- ChromoteSession$new(width = 960, height = 540)
  b$Page$navigate(paste0("file://", file.path(here, deck)))
  b$Page$loadEventFired(wait_ = TRUE)
  Sys.sleep(2.5)

  n <- b$Runtime$evaluate("Reveal.getTotalSlides()", returnByValue = TRUE)$result$value
  msgs <- character()
  for (i in seq_len(n)) {
    b$Runtime$evaluate(sprintf("Reveal.slide(%d)", i - 1L))
    Sys.sleep(0.75)
    hit <- b$Runtime$evaluate(probe, returnByValue = TRUE)$result$value %||% ""
    if (nzchar(hit)) msgs <- c(msgs, sprintf("slide %d:\n%s", i, hit))
  }
  b$close()

  if (length(msgs)) {
    total <- total + length(msgs)
    cat("\nFAIL ", deck, "\n", paste(msgs, collapse = "\n"), "\n", sep = "")
  } else {
    cat("ok   ", deck, " (", n, " slides)\n", sep = "")
  }
}

cat("\nslides with a problem:", total, "\n")
if (total > 0) quit(status = 1)
