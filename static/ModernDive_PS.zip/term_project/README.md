# Jenny's commments

On Albert's original `data_proposal.Rmd`

* typo line 18 (each code chunk *in*)
* the link for the `Rmd` on the course site is not working
* I would give them the `Rmd` *empty* of the answers to fill in and knit for instructions
* I would *separately* give them the `html` file of your example (with the school data)
* I would not hide the code chunk showing the `library()` for now....that is just me. I think that might be too much at once
* Don't forget to point them to the `Rninja` file for help (and to post that)
* I would make it **EXTREMELY CLEAR** that not every group is going to need to take the exact steps you did in the example...or you are going to have students spending hours trying to figure out how they can use the cut_numbers function in their data


# Next time:

* Rename the 5 phases. Students got confused by difference between "data proposal"
vs "project proposal". Perhaps name the latter "EDA"