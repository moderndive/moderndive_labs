# Visit every slide of every deck and report anything drawn off the 960x540 page.
#
#   Rscript check_overflow.R            every deck
#   Rscript check_overflow.R ch05       just the ones whose name starts ch05
#
# Run it after ./render.sh. Each slide has to be visited rather than measured in
# one pass: reveal.js only lays out the slides near the current one, and the
# annotation layer only places labels on a slide it can measure. A slide that is
# still hidden reports every box as zero, which is silently "no overflow".

suppressPackageStartupMessages(library(chromote))

`%||%` <- function(a, b) if (is.null(a)) b else a

here <- normalizePath(dirname(sub("^--file=", "",
  grep("^--file=", commandArgs(FALSE), value = TRUE)[1] %||% ".")))
args <- commandArgs(TRUE)

decks <- sort(list.files(here, pattern = "\\.html$"))
if (length(args)) {
  decks <- decks[Reduce(`|`, lapply(args, function(a) startsWith(decks, a)))]
}
if (!length(decks)) stop("no rendered decks match; run ./render.sh first")

# Elements that legitimately contain others are still worth measuring; the rest
# are skipped so a wrapper is not reported alongside the text inside it.
MEASURED <- "div.sourceCode,.brace,.chip,.banner,.note,.deck-caption,li"

probe <- sprintf('(function(){
  var s = document.querySelector("section.present"); if (!s) return "";
  var sec = s.getBoundingClientRect(), out = [];
  s.querySelectorAll("*").forEach(function (el) {
    if (el.children.length && !el.matches(%s)) return;
    var r = el.getBoundingClientRect(); if (!r.width && !r.height) return;
    var left = r.left - sec.left, bottom = r.bottom - sec.top;
    // A code band is capped by max-width, so its box can sit inside the page
    // while the call inside it runs off the edge. Measure what the text needs.
    var right = left + Math.max(r.width, el.scrollWidth || 0);
    if (right > 962 || bottom > 542 || left < -2) {
      out.push("  " + el.tagName.toLowerCase() + "." +
        (el.className || "").toString().trim().slice(0, 24) +
        " [" + Math.round(left) + "," + Math.round(r.top - sec.top) +
        " -> " + Math.round(right) + "," + Math.round(bottom) + "] " +
        JSON.stringify((el.textContent || "").trim().slice(0, 34)));
    }
  });
  return out.join("\\n");
})()', shQuote(MEASURED, type = "cmd"))

# The gutter word and the code band are the one pair that can end up on top of
# each other: a wide call grows leftward from the right margin, and a long
# gutter word reaches right. Nothing else on a slide shares a band of the page.
overlap <- '(function () {
  var s = document.querySelector("section.present"); if (!s) return "";
  var word = s.querySelector(".example-label");
  var band = s.querySelector("div.sourceCode");
  if (!word || !band) return "";
  var a = word.getBoundingClientRect(), b = band.getBoundingClientRect();
  if (a.right <= b.left || b.right <= a.left) return "";
  if (a.bottom <= b.top || b.bottom <= a.top) return "";
  return "  the gutter word and the code band overlap by " +
    Math.round(Math.min(a.right, b.right) - Math.max(a.left, b.left)) + "pt";
})()'

total <- 0L
for (deck in decks) {
  b <- ChromoteSession$new(width = 960, height = 540)
  on.exit(try(b$close(), silent = TRUE), add = TRUE)
  b$Page$navigate(paste0("file://", file.path(here, deck)))
  b$Page$loadEventFired(wait_ = TRUE)
  Sys.sleep(2.5)

  n <- b$Runtime$evaluate("Reveal.getTotalSlides()", returnByValue = TRUE)$result$value
  msgs <- character()
  for (i in seq_len(n)) {
    b$Runtime$evaluate(sprintf("Reveal.slide(%d)", i - 1L))
    Sys.sleep(0.75)
    hit <- b$Runtime$evaluate(probe, returnByValue = TRUE)$result$value %||% ""
    clash <- b$Runtime$evaluate(overlap, returnByValue = TRUE)$result$value %||% ""
    hit <- paste(c(hit[nzchar(hit)], clash[nzchar(clash)]), collapse = "\n")
    if (nzchar(hit)) msgs <- c(msgs, sprintf("slide %d:\n%s", i, hit))
  }
  b$close()

  if (length(msgs)) {
    total <- total + length(msgs)
    cat("\nFAIL ", deck, "\n", paste(msgs, collapse = "\n"), "\n", sep = "")
  } else {
    cat("ok   ", deck, " (", n, " slides)\n", sep = "")
  }
}

cat("\nslides with something off the page:", total, "\n")
if (total > 0) quit(status = 1)
