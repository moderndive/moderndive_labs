# Fail a brace, label, or side arrow that lands somewhere else when the window
# is not 960 x 540.
#
#   Rscript check_scale.R            every deck (about 10 minutes)
#   Rscript check_scale.R ch04       just the ones whose name starts ch04
#
# Run it after ./render.sh, and after any change to _theme/annotate.js. reveal.js
# scales a slide to fit the window, so every mark annotate.js places has to be
# written in slide pixels. Until 2026-10-12, place() wrote screen pixels, which
# are right only at scale 1: the PDF and every check at 960 x 540 looked fine,
# while a deck opened or widened to any other size drew its braces off their
# code (ch04 slide 4's brace was 452 slide pixels off at 1440 x 810).
#
# Per deck, it records each mark at 960 x 540 in slide pixels (screen pixels
# divided by the scale, from the slide's top left), then lays the deck out again
# at three other sizes, two ways each:
#
#   opened at    the deck loads at that size
#   resized to   the deck loads at 960 x 540 and the window changes before any
#                slide is visited, as when a reader widens the window mid-deck
#
# annotate.js places a slide's marks the first time it is shown, so resizing
# after every slide has been seen cannot fail; this check does not do that.
# A mark that moves more than 2 slide pixels fails. check_layout.R checks what
# the slides look like; this checks only that they look the same at any size.

suppressPackageStartupMessages({ library(chromote); library(jsonlite) })

`%||%` <- function(a, b) if (is.null(a)) b else a

here <- normalizePath(dirname(sub("^--file=", "",
  grep("^--file=", commandArgs(FALSE), value = TRUE)[1] %||% ".")))
args <- commandArgs(TRUE)

decks <- sort(list.files(here, pattern = "^ch.*\\.html$"))
if (length(args)) {
  decks <- decks[Reduce(`|`, lapply(args, function(a) startsWith(decks, a)))]
}
if (!length(decks)) stop("no rendered decks match; run ./render.sh first")

SIZES <- list(c(800, 450), c(1440, 810), c(1200, 900))
TOLERANCE <- 2   # slide pixels

probe <- '(function () {
  var s = document.querySelector(".reveal .slides section.present");
  if (!s) return "[]";
  var k = Reveal.getScale(), sb = s.getBoundingClientRect(), out = [];
  function add(kind, el, i) {
    var b = el.getBoundingClientRect();
    if (!b.width && !b.height) return;
    out.push({ mark: kind + " " + (i + 1),
               l: (b.left - sb.left) / k, r: (b.right - sb.left) / k,
               t: (b.top - sb.top) / k, b: (b.bottom - sb.top) / k });
  }
  s.querySelectorAll(".bracegap path").forEach(function (e, i) { add("brace", e, i); });
  s.querySelectorAll(".placed .brace, .placed .chip").forEach(function (e, i) { add("label", e, i); });
  s.querySelectorAll(".side-marks path").forEach(function (e, i) { add("side arrow", e, i); });
  s.querySelectorAll("pre code").forEach(function (e, i) { add("code", e, i); });
  return JSON.stringify(out);
})()'

open_at <- function(deck, w, h) {
  b <- ChromoteSession$new(width = w, height = h)
  b$Page$navigate(paste0("file://", file.path(here, deck)))
  b$Page$loadEventFired(wait_ = TRUE)
  Sys.sleep(2.5)
  b
}

measure <- function(b) {
  n <- b$Runtime$evaluate("Reveal.getTotalSlides()", returnByValue = TRUE)$result$value
  lapply(seq_len(n), function(i) {
    b$Runtime$evaluate(sprintf("Reveal.slide(%d)", i - 1L))
    Sys.sleep(0.6)
    fromJSON(b$Runtime$evaluate(probe, returnByValue = TRUE)$result$value)
  })
}

compare <- function(base, got) {
  msgs <- character()
  for (i in seq_along(base)) {
    a <- base[[i]]; g <- got[[i]]
    if (NROW(a) != NROW(g)) {
      msgs <- c(msgs, sprintf("slide %d: %d marks at 960 x 540, %d here", i, NROW(a), NROW(g)))
      next
    }
    if (!NROW(a)) next
    d <- pmax(abs(a$l - g$l), abs(a$r - g$r), abs(a$t - g$t), abs(a$b - g$b))
    for (j in which(d > TOLERANCE)) {
      msgs <- c(msgs, sprintf("slide %d: %s moved %.0f [%.0f -> %.0f, at 960 %.0f -> %.0f]",
        i, a$mark[j], d[j], g$l[j], g$r[j], a$l[j], a$r[j]))
    }
  }
  msgs
}

total <- 0L
for (deck in decks) {
  b <- open_at(deck, 960, 540)
  base <- measure(b)
  b$close()
  marks <- sum(vapply(base, NROW, 1L))
  msgs <- character()
  for (s in SIZES) {
    b <- open_at(deck, s[1], s[2])
    m <- compare(base, measure(b))
    if (length(m)) msgs <- c(msgs, sprintf("opened at %dx%d:", s[1], s[2]), paste0("  ", m))
    b$close()

    b <- open_at(deck, 960, 540)
    b$Emulation$setDeviceMetricsOverride(width = s[1], height = s[2],
      deviceScaleFactor = 1, mobile = FALSE)
    Sys.sleep(1.5)
    m <- compare(base, measure(b))
    if (length(m)) msgs <- c(msgs, sprintf("resized to %dx%d:", s[1], s[2]), paste0("  ", m))
    b$close()
  }
  if (length(msgs)) {
    total <- total + 1L
    cat("\nFAIL ", deck, "\n", paste(msgs, collapse = "\n"), "\n", sep = "")
  } else {
    cat("ok   ", deck, " (", length(base), " slides, ", marks, " marks, 6 layouts)\n", sep = "")
  }
}

cat("\ndecks with a mark that moved:", total, "\n")
if (total > 0) quit(status = 1)
