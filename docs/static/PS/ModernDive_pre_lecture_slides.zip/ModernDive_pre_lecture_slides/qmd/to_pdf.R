# Print each rendered deck to PDF, one page per slide.
#
#   Rscript to_pdf.R            every deck
#   Rscript to_pdf.R ch05       just the ones whose name starts ch05
#
# Run it after ./render.sh, or use `./render.sh --pdf`, which does both.
#
# Two things about the geometry are easy to get wrong:
#
#   * A slide is 960 x 540 *CSS pixels*, which at 96dpi is 720 x 405 points, not
#     960 x 540. Asking Chrome for a 960x540pt page makes reveal scale the slide
#     down to fit and leaves a white margin all round.
#   * The deck has to be opened with `?print-pdf`. That is what makes reveal lay
#     every slide out at once instead of only the ones near the current slide,
#     and the annotation layer keys off it to place every label in one pass.

suppressPackageStartupMessages(library(chromote))

`%||%` <- function(a, b) if (is.null(a)) b else a

here <- normalizePath(dirname(sub("^--file=", "",
  grep("^--file=", commandArgs(FALSE), value = TRUE)[1] %||% ".")))
args <- commandArgs(TRUE)

decks <- sort(list.files(here, pattern = "\\.html$"))
if (length(args)) {
  decks <- decks[Reduce(`|`, lapply(args, function(a) startsWith(decks, a)))]
}
if (!length(decks)) stop("no rendered decks match; run ./render.sh first")

for (deck in decks) {
  stem <- sub("\\.html$", "", deck)
  out <- file.path(here, paste0(stem, ".pdf"))

  b <- ChromoteSession$new(width = 960, height = 540)
  b$Page$navigate(paste0("file://", file.path(here, deck), "?print-pdf"))
  b$Page$loadEventFired(wait_ = TRUE)
  Sys.sleep(6)   # reveal lays the whole deck out, then the labels are placed

  n <- b$Runtime$evaluate(
    "document.querySelectorAll('.reveal .slides section').length",
    returnByValue = TRUE)$result$value
  done <- b$Runtime$evaluate(
    "document.querySelectorAll('section[data-pl-annotated]').length",
    returnByValue = TRUE)$result$value

  if (!identical(as.integer(done), as.integer(n))) {
    warning(sprintf("%s: %d of %d slides annotated before printing", deck, done, n))
  }

  res <- b$Page$printToPDF(
    printBackground = TRUE, preferCSSPageSize = FALSE,
    paperWidth = 960 / 96, paperHeight = 540 / 96,
    marginTop = 0, marginBottom = 0, marginLeft = 0, marginRight = 0,
    pageRanges = paste0("1-", n))
  writeBin(jsonlite::base64_dec(res$data), out)
  b$close()

  cat(sprintf("%-40s %2d pages\n", basename(out), n))
}
