// Run by check_layout.R on the slide being shown. Returns "" when the slide is
// clean, otherwise one line per problem. See check_layout.R for what each kind
// of problem means.
(function () {
  var s = document.querySelector(".reveal .slides section.present");
  if (!s) return "  no slide is showing";
  var scale = (window.Reveal && Reveal.getScale) ? Reveal.getScale() : 1;
  var sec = s.getBoundingClientRect();
  var out = [];

  function rel(b) {
    return { l: (b.left - sec.left) / scale, t: (b.top - sec.top) / scale,
             r: (b.right - sec.left) / scale, b: (b.bottom - sec.top) / scale };
  }
  function visible(el) {
    for (var e = el; e && e !== s; e = e.parentElement) {
      var cs = getComputedStyle(e);
      if (cs.display === "none" || cs.visibility === "hidden" ||
          parseFloat(cs.opacity) === 0) return false;
    }
    return true;
  }
  // The boxes the ink actually occupies: one per line of text, not the block's
  // full width, so a short heading does not "overlap" a note across the page.
  function boxes(el) {
    var tag = el.tagName.toLowerCase();
    if (tag === "img" || el.classList.contains("diagram") || tag === "table") {
      var b = el.getBoundingClientRect();
      return b.width && b.height ? [rel(b)] : [];
    }
    // Text nodes only: a range over an element also returns the full-width box
    // of every block inside it, such as each <li>, which is not ink.
    var out = [];
    var w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
    var n;
    while ((n = w.nextNode())) {
      if (!n.nodeValue.trim() || !visible(n.parentElement)) continue;
      var r = document.createRange();
      r.selectNodeContents(n);
      Array.prototype.forEach.call(r.getClientRects(), function (b) {
        if (b.width > 1 && b.height > 1) out.push(rel(b));
      });
    }
    return out;
  }
  function name(el) {
    var c = (el.className && el.className.baseVal === undefined ? el.className : "")
      .toString().trim().split(/\s+/).filter(function (x) {
        return x && !/^(placed|up|down|cell|sourceCode|r)$/.test(x);
      }).slice(0, 2).join(".");
    var t = (el.getAttribute("alt") || el.textContent || "").trim().replace(/\s+/g, " ");
    return el.tagName.toLowerCase() + (c ? "." + c : "") +
      ' "' + t.slice(0, 28) + (t.length > 28 ? "..." : "") + '"';
  }

  var SEL = [
    "h2", "div.sourceCode", "div.cell-output-stdout", "img", ".diagram", "table", "ul", "ol",
    ".note", ".banner", ".standfirst", ".deck-caption", ".footnote",
    ".example-label", ".brace", ".chip", ".corner", ".corner-chip", ".step",
    ".pipe-block", ".pipe-chip", ".callout-red"
  ].join(",");
  var items = [];
  s.querySelectorAll(SEL).forEach(function (el) {
    if (!visible(el)) {
      if (el.matches(".example-label,.note,.brace,.chip,.banner")) {
        out.push("  hidden: " + name(el));
      }
      return;
    }
    // A table or list is one block; what is inside it is not measured again.
    if (el.closest("table") && el.tagName !== "TABLE") return;
    if (el.closest(".diagram") && !el.classList.contains("diagram")) return;
    var bx = boxes(el);
    if (!bx.length) {
      if (el.matches(".example-label,.note,.brace,.chip,.banner")) {
        out.push("  hidden: " + name(el) + " takes no space");
      }
      return;
    }
    items.push({ el: el, bx: bx });
  });
  // A plain paragraph of text (a concept slide's definition is one) is not
  // matched by any class above, so take every paragraph with text of its own.
  s.querySelectorAll("p").forEach(function (p) {
    if (!visible(p) || p.closest("table,li,.diagram")) return;
    var own = Array.prototype.some.call(p.childNodes, function (n) {
      return n.nodeType === 3 && n.nodeValue.trim();
    });
    if (!own || p.querySelector(SEL)) return;
    var bx = boxes(p);
    if (bx.length) items.push({ el: p, bx: bx });
  });

  // off-page
  items.forEach(function (it) {
    it.bx.forEach(function (b) {
      if (b.r > 962 || b.b > 542 || b.l < -2 || b.t < -2) {
        out.push("  off-page: " + name(it.el) + " [" + Math.round(b.l) + "," +
          Math.round(b.t) + " -> " + Math.round(b.r) + "," + Math.round(b.b) + "]");
      }
    });
  });

  // edge: text that reaches a side of the page. It passes off-page, yet a
  // viewer that trims or scales the page even slightly cuts its first or last
  // letters off (ch04's "what to call the result" sat at x = 0, 2026-10-12).
  // Pictures and diagrams may run to the edge. Text keeps 8px on the left (the
  // opener lists and "Example" sit at 21-29 by design) and 30px on the right,
  // where nothing but two side labels went past 930 (fixed 2026-10-12).
  items.forEach(function (it) {
    if (it.el.matches("img,.diagram")) return;
    it.bx.forEach(function (b) {
      if (b.l < 8 || b.r > 932) {
        out.push("  edge: " + name(it.el) + " [" + Math.round(b.l) + " -> " +
          Math.round(b.r) + "] is too close to the side of the page");
      }
    });
  });

  // overlap: any line box of one item crossing any line box of another
  function hit(a, b) {
    var w = Math.min(a.r, b.r) - Math.max(a.l, b.l);
    var h = Math.min(a.b, b.b) - Math.max(a.t, b.t);
    return w > 2 && h > 2 ? [w, h] : null;
  }
  for (var i = 0; i < items.length; i++) {
    for (var j = i + 1; j < items.length; j++) {
      var A = items[i], B = items[j];
      if (A.el.contains(B.el) || B.el.contains(A.el)) continue;
      var found = null;
      A.bx.forEach(function (a) {
        B.bx.forEach(function (b) { found = found || hit(a, b); });
      });
      if (found) {
        out.push("  overlap: " + name(A.el) + " and " + name(B.el) + " by " +
          Math.round(found[0]) + "x" + Math.round(found[1]) + "px");
      }
    }
  }

  // small-code: the decks are designed at 24px code; under 18px is hard to read
  // from the back of a room.
  s.querySelectorAll("div.sourceCode code").forEach(function (c) {
    var px = parseFloat(getComputedStyle(c).fontSize);
    if (px < 18) out.push("  small-code: " + px.toFixed(1) + "px in " + name(c));
  });
  // A printout is read, not typed, so it may go down to 16px to fit.
  s.querySelectorAll("div.cell-output-stdout code").forEach(function (c) {
    var px = parseFloat(getComputedStyle(c).fontSize);
    if (px < 16) out.push("  small-code: " + px.toFixed(1) + "px in output " + name(c));
  });

  // wrong-line, flagged by annotate.js as it placed the braces
  s.querySelectorAll("[data-pl-wrong-line]").forEach(function (el) {
    out.push("  wrong-line: " + name(el) + " names code on a line its row cannot reach");
  });

  // empty
  var ink = items.some(function (it) {
    return it.el.tagName === "IMG" || (it.el.textContent || "").trim().length;
  });
  if (!ink) out.push("  empty: nothing visible on this slide");

  // alt
  s.querySelectorAll("img").forEach(function (img) {
    if (!img.hasAttribute("alt")) {
      out.push("  alt: " + name(img) + " has no alt attribute");
    } else if (img.getAttribute("alt") === "" &&
               img.getAttribute("aria-hidden") !== "true") {
      out.push("  alt: " + name(img) + ' has alt="" but is not aria-hidden');
    }
  });
  s.querySelectorAll(".diagram").forEach(function (d) {
    if (!d.getAttribute("aria-label")) out.push("  alt: a diagram has no aria-label");
  });

  // contrast, for every element that sets text of its own
  function rgba(str) {
    var m = str.match(/rgba?\(([^)]+)\)/);
    if (!m) return [0, 0, 0, 1];
    var p = m[1].split(",").map(parseFloat);
    return [p[0], p[1], p[2], p.length > 3 ? p[3] : 1];
  }
  function lum(c) {
    var v = c.slice(0, 3).map(function (x) {
      x /= 255;
      return x <= 0.03928 ? x / 12.92 : Math.pow((x + 0.055) / 1.055, 2.4);
    });
    return 0.2126 * v[0] + 0.7152 * v[1] + 0.0722 * v[2];
  }
  function background(el) {
    for (var e = el; e; e = e.parentElement) {
      var c = rgba(getComputedStyle(e).backgroundColor);
      if (c[3] > 0.5) return c;
    }
    return [255, 255, 255, 1];
  }
  var seen = {};
  var walker = document.createTreeWalker(s, NodeFilter.SHOW_TEXT);
  var node;
  while ((node = walker.nextNode())) {
    if (!node.nodeValue.trim()) continue;
    var el = node.parentElement;
    if (!visible(el) || el.closest("[aria-hidden='true']")) continue;
    if (el.closest(".slide-number")) continue;
    var cs = getComputedStyle(el);
    var fg = rgba(cs.color), bg = background(el);
    var L1 = lum(fg), L2 = lum(bg);
    var ratio = (Math.max(L1, L2) + 0.05) / (Math.min(L1, L2) + 0.05);
    var px = parseFloat(cs.fontSize), bold = parseInt(cs.fontWeight, 10) >= 700;
    var need = (px >= 24 || (bold && px >= 18.66)) ? 3 : 4.5;
    var key = cs.color + "|" + bg.join(",") + "|" + need;
    if (ratio < need && !seen[key]) {
      seen[key] = 1;
      out.push("  contrast: " + ratio.toFixed(2) + ":1, needs " + need + ":1, " +
        cs.color + " on rgb(" + bg.slice(0, 3).join(", ") + ") at " +
        px.toFixed(1) + "px in " + name(el));
    }
  }

  return out.join("\n");
})()
