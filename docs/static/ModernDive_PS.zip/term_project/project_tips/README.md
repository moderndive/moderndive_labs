# Contents

* `project_tips.Rmd` Albert's version, built off Jenny's version. Note that this `.Rmd` file uses local images in `/figures`; remove the code that loads these images before sharing with students.
    + TODO: Change `parse_number()` examples to be embeded in a `mutate()` instead of stand-alone using non-data frame inputs
* `project_tips_jenny.Rmd` Jenny's original version.
* `project_tips_jenny_file_for_students.Rmd` Jenny's original version to share with students; this does not load local images in `/figures`

